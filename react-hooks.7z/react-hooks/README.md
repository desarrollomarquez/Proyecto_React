# React CRUD App with Hooks

Running React 16.7.0-alpha

- View all users
- Add a new user
- Delete a user
- Edit an existing user