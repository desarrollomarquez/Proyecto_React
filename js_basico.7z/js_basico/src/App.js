import React from 'react';
import logo from './logo.svg';
import './App.css';
import {Cuadrado, Triangulo} from './poligonos.js';
import NodeFetch from 'node-fetch'
import { async, reject } from 'q';
import { resolve } from 'path';
var fs = require('fs');
var cont = 0;

function App() {

  var name = "Diego" 
  console.log("Repaso Javascript ES6: "+cont++)
  
 //////////////// Ambito Hoisting la variable sale del ambito comun////////////
  for (var i=0; i<7; i++){
    //console.log(i);
  }
  //console.log(i + 3); //devuelve 10
  var j
  for (j=1; j < 11; j++){
    //console.log(j);
  }
  //console.log(j+2); // devuelve 13
  ////////////// ES6 Let -> el tipo de variable quita el Ambito Hoisting ///////////
  var a = 3;

  if (a < 5 ){
    let b = 10; 
    //var b = 10;
    //console.log(a+b);
  }
  //console.log(b); // En consola indica que la variable no esta definida por lo que muestra que quita el ambito.
  /////////////////// callbacks////////////////////////////////////////////
  var vocales = ['a','e','i','o','u'];
  function foo(){
    for (let i=0; i < 5; i++){
        //bar(function(){
           // console.log('La vocal es :' + vocales[i]);
        //});
    }
  }
  
  var vocales = ['a','e','i','o','u'];
  var consonantes = ['gui','gue','guas'];
  vocales.forEach(elem => {
          if(elem === 'o' ){
         // console.log("Encontrado");
          }
          else{
         //   console.log(elem);
          }
        });
  consonantes.map(conso => {
          if(conso === 'gui'){
           // console.log("Consonante");        
          }
          else{
             // console.log(conso);
          }
    
         } );
  
  /////////////////Diferencia entre las funciones Flecha Forech y Map///////////////////////////////////////////
  // FORECH
  var result = [1,2,3,4];
  var r1;
  r1 = result.forEach(item =>  item); 
  //console.log("Foreach: "+r1)
  // El foreach no guarda en una variable, se muestra como indefinido seria solo una funcion flecha para mostrar 
  
  //MAP()
  var result_map= [1,2,3,4]
  var r2;
  r2 = result_map.map(i => i );
  //console.log("Map: "+r2)
  // El Map si guarda en una variable, seria un funcion flecha para guardar y mostrar.
  ///////////////////////////////////////////// CONSTANTES ////////////////////////////////////////////
  const max_size = 4;
  const number = 3
  var sum = 0;
  for(let i =0; i <= max_size; i++ ){
    const MSG = 'Variable :-> ';
    sum = i+ number;
   // console.log(MSG+sum)
  }

  const GAME = {lives:3, width: 500, height:300 }
 // console.log(GAME.lives)
  GAME.lives = 10
 // console.log(GAME.lives)

  const GAMES = Object.freeze({lives:3, width: 500, height:300 }) // Definir un objeto inmutable
  //GAMES.lives = 30 -> No funciona ya que Object Freeze convierte un objeto en inmutable
  //console.log(Object.isFrozen(GAMES)); // Pregunta si el objeto es inmutable
  ////////////////////////////// FUNCIONES ///////////////////////////////////////////////////////////////////
  ////////////// Valores por defecto ////////////////////////////////////////////////////////////////
  //////////// Funciones variadicas ///////////////////////////////////////////////////////////////////
  function ejemplo(nombre, apellidos = "Garcia"){
      if(apellidos !== undefined){
      //  console.log("Hola "+nombre+" "+apellidos);
      }
      else{
       // console.log("Hola "+nombre);  
      }
  }

 // ejemplo("Manuel")
  //ejemplo("PEPE","grillo")
  //////////////////////////////////////Parámetro REST  ////////////////////////////////////////////////////////
  function ejemplo2 (param1, param2, ...restparams){ // Este ultimo argumento toma los demas parametros de la funcion
  //  console.log(restparams)
  }
  //ejemplo2('a', 'b', 'c', 'd')
  /////////////////////////////////////Operador SPREAD //////////////////////////////////////////////////////
  let aVocales = ['a','e','i','o','u']; //Array 
  function bar(){   
    console.log(arguments[0])
    let txt = '';
    for(let i in arguments){
      //console.log(arguments[i])
      txt += arguments[i]; 
    }
    console.log(txt); 
  }
  
  function foo(a){
  //  console.log(a.length);
    bar(a);
  }
  //foo(aVocales)

//////////////////////////////// Funciones ARROW /////////////////////////////////////////////////////
//let multiplicar = function(a,b){ return a*b };
let multiplicar = (a,b) => a*b;
//console.log(multiplicar(3,5))
////////////////////////////////////////////////////////
// let ImageHandler = {
//                 id: "",
//                 init: function (id) {
//                           this.id = id;
//                           let that = this;
//                           document.addEventListener("click", function (event) {
//                           that.show(event); // se usa that aquí, porque this haría referencia al contexto de la función anónima
//                           }, false);
//                 },
//                 show: function (event) {
//                 console.log("Se ha disparado el evento de typo " + event.type);
//                 }
// };


let ImageHandler = { // con => flecha
              id: "",
              init: function (id) {
                  this.id = id;
                  document.addEventListener("click", (event) => this.show(event),
                  false);
              },
              show: function (event) {
              console.log(event.type + " has been fired for " + this.id);
              }
  };
/////////////////////////////// . Objetos y Arrays ///////////////////////////////////////
///////////////////////////// Forma abreviada para quitar repeticiones /////////////////
// function getSizes(){
//       let width = window.innerWidth;
//       let height = window.innerHeight - 200;
//       return {width: width, height: height};
//   }
  // function getSizes(){
  //     let width = window.innerWidth;
  //     let height = window.innerHeight - 200;
  //     return {width, height};
  // }

  // let sizes = {width, height};
  // console.log(sizes.width);
  ////////////////////////////////////// Asignación por Destructuring //////////////////////////

  let Vocales = ["a", "e", "i", "o", "u"];
  let [z, y, ...x] = Vocales; // tambien funciona con el operador spread
 // console.log(z); //a
 // console.log(y); //e
 // console.log(x); //i
  //console.log(w); //o
  //console.log(v); //u

 /////////////////////////////////////////// Iteraciones: for… in vs for… of ////////////////////

 let jugador = {
  name: "Sergio Callejas",
  posicion: "4",
  esTitular: true,
  dorsal: 33
  }

  for (i in jugador){
  //console.log(i, eval('jugador.' + i));
  }

  for (j in jugador){
   //console.log(j, jugador[j]);
  }
  //console.log(i.name)
  //console.log(j["name"])


  var equipo = [
    {name: "David Gómez", posicion: "5"},
    {name: "Sergio Callejas", posicion: "4"},
    {name: "Javier Rodríguez", posicion: "3"},
    {name: "Laura Fernández", posicion: "2"},
    {name: "Manuel Fernández", posicion: "1"}
    ]
    //recorremos por posición que ocupa en el array
 
  for (jugador of equipo){  
    //console.log(jugador.name);
  }
  for (i in equipo){
    //console.log(equipo[i]);
  }
  ////////////////  Entendiendo Iteradores, y como crearlos /////////////////////////////////////

  // let iterador = equipo[Symbol.iterator]();
  // console.log(iterador.next())

  equipo[Symbol.iterator]= function(){
    let listaPosiciones = Object.keys(this);
    let i = 0;

    let next = () => {
      let posicion = listaPosiciones[i];
        return {
                value: this[posicion],
                done: (i++ >= listaPosiciones.length )
        };
    };
    return {next};
  }
  let miembro;
  for(miembro of equipo){
    //console.log(miembro);
  }

  ///////////////// Generadores ///////////////////////////////////////////////
//devuelve el primer yield, y se guarda el estado a la espera de que en algún momento se vuelva a
// llamar a next(). Cuando se llame a next() por segunda vez, devolverá el segundo yield. Y
//así hasta que no haya más.
  function* miGenerador(){
    yield "uno";
    yield "dos";
    yield "tres";
    }
  let genera = miGenerador();
  //console.log(genera.next())
  //console.log(genera.next())
  //console.log(genera.next())

  let wizardBox = {
            step1 : function(){
            console.log("paso 1 de 3");
            },
            step2 : function(){
            console.log("paso 2 de 3");
            },
            step3 : function(){
            console.log("paso 3 de 3");
            }
    }
    function* wizard(){
          yield wizardBox.step1();
          yield wizardBox.step2();
          yield wizardBox.step3();
    }
    let w = wizard();
    //w.next();
    //ejecutamos el primer paso y hacemos lo que sea
   // w.next();
    //se ejecuta el segundo paso continuado donde lo dejamos
   // w.next();
    //se ejecuta el tercer paso continuando desde el punto anterior
  
    equipo[Symbol.iterator] = function *(){
      let listaPosiciones = Object.keys(this);
        for (let posicion of listaPosiciones){
              yield this[posicion];
        }
      };
    let p;
      for(p of equipo){
       // console.log(p);
      }
///////////////////////////////////// Los nuevos tipos Map ////////////////////////
//En esta versión de JavaScript se introducen cuatro tipos nuevos de objetos: Map, WeakMap, Set y WeakSet.
//Los mapas son un conjunto de pares clave, valor que implementan algunas operaciones: Añadir, Obtener, consultar,
// eliminar, vaciar. En el caso concreto de los mapas, son iterables, y admiten pares de objetos, tanto en las
//claves como en los valores con los maps se pueden repetir valores:
let equipacion = new Map();

equipacion.set('camiseta',{size:'XXL', dorsal:'02'});
equipacion.set('zapatillas',46);
equipacion.set('pantalones','54');
//console.log(equipacion.get('zapatillas')); //46
//console.log(equipacion.get('camiseta').size); //XXL
//console.log(equipacion.size); //3
//console.log(equipacion.has('pantalones')); //true
equipacion.delete('pantalones') //quitamos el elemento pantalones
//console.log(equipacion.has('pantalones')); //false
equipacion.clear(); //vaciamos el mapa
//console.log(equipacion.size); //0
equipacion.set(equipo.posteBajo, {camiseta: 'XXXL', pie: 46});
//console.log(equipacion.get(equipo.posteBajo));

////////////////////////////////// WeakMap() ///////////////////////////////////////////////////////////
/// WeakMap son un tipo de mapas “débiles”. La primera diferencia es que las claves sólo pueden ser objetos. Nunca strings. Tampoco son iterables, y como
//tal no puedes consultar sus claves con Object.keys(). Además, hay que tener en cuenta que sus objetos se encuentran referenciados de forma "weak" (débil). Esto quiere decir,
//que el objeto que forma parte de la clave, si no es referenciado por nadie más que el WeakMap, es susceptible de que el Garbage Collector lo elimine
let wm1 = new WeakMap(),
    wm2 = new WeakMap(),
    wm3 = new WeakMap();

let o1 = {},
    o2 = function(){},
    o3 = window;

    wm1.set(o1, 37);
    wm1.set(o2, 'azerty');
    wm2.set(o1, o2); // a value can be anything, including an object or a function
    wm2.set(o3, undefined);
    wm2.set(wm1, wm2); // keys and values can be any objects. Even WeakMaps!
    
   // console.log(wm1.get(o2)); // "azerty"
   // console.log(wm2.get(o2)); // undefined, because there is no key for o2 on wm2
   // console.log(wm2.get(o3)); // undefined, because that is the set value
    
    wm1.has(o2); // true
    wm2.has(o2); // false
    wm2.has(o3); // true (even if the value itself is 'undefined')
    
    wm3.set(o1, 37);
   // console.log(wm3.get(o1)); // 37
    
    wm1.has(o1); // true
    wm1.delete(o1);
    wm1.has(o1); // false

    ////////////////////////////////// Los nuevos tipos Set y WeakSet ///////////////////////////////
    let vocales_set = new Set();
    vocales_set.add('a');
    vocales_set.add('e');
    vocales_set.add('i');
    vocales_set.add('o');
    vocales_set.add('u');
    vocales_set.add('a');
    vocales_set.add('u');
    //console.log(vocales_set);
    for (let vocal of vocales_set){
      //  console.log(vocal)
    }

    ////////////////////////////////////// Clases ///////////////////////////////////////////////////
    ////////////////// Objeto con una unica instancia///////////////////////
    let tablero = {
        filas: 20,
        columnas: 20,
        bombas: 15,
        render: function(){
    //      console.log("Objeto Unico..");
        }
      };
  //  console.log(tablero.columnas)
//////////////////////// Entendiendo los prototipos ////////////////////////////////////////////
//El prototipo de un objeto es un objeto que nos devuelve su constructor y sus métodos. Con lo cual se puede recrear el objeto a partir de su prototipo.
  // function Rectangulo(alto, ancho){
  // this.alto = alto;
  // this.ancho = ancho;
  // }
  // Rectangulo.prototype.area = function(){
  // return this.alto * this.ancho;
  // }
  // let rectangulo1 = new Rectangulo(3,5);
  // console.log(Rectangulo.prototype); //15
  
  // function Cuadrado(lado){
  //   this.lado = lado;
  //   this.alto = lado;
  //   this.ancho = lado;
  //   }
  //   Cuadrado.prototype = Object.create(Rectangulo.prototype);
  //   let cuadrado1 = new Cuadrado(2);
  //   console.log(cuadrado1.area()); //4

  //   console.log(cuadrado1 instanceof Cuadrado); //true
  //   console.log(cuadrado1 instanceof Rectangulo); //true
/////////////////////////////////////// Clases ///////////////////////////////////////////////////////
/// Esta necesidad se ha visto satisfecha en la versión ES6. Y así, ahora tenemos clases para definir objetos.


class Rectangulo {
      constructor(alto, ancho){
      this.name = "Rectangulo"
      this.alto = alto;
      this.ancho = ancho;
      };
      area_r(){
      return this.alto * this.ancho;
      };
};

 let r = new Rectangulo(2,3);
 console.log(r.name+" -> "+r.area_r()); //6

////////////////////////////// Clases - Herencia -> Prototipos Iniciales ////////////////////////////////////////////////////
class Cuadrado extends Rectangulo {
    constructor(lado){
    super(lado,lado);
    this.name = "Cuadrado"
    this.lado = lado;
    };
};
let cc = new Cuadrado(3);
//console.log(c.area()); //9



class Triangulo  extends Cuadrado{
  constructor(base, altura){
    super(base, altura)
    this.name = "Triangulo"
    this.base    = base;
    this.altura  = altura;
  };
  area_t(){
      return (this.base * this.altura)/2;
  };
};
let t = new Triangulo(4,3);
console.log("Rectangulo: "+t.area_r()); //10
console.log("Triangulo : "+t.area_t()); //10

/////////////////// Pendiente Definir las partes de las clases en javascript--- Ojo muy importante ///////////
// Los ‘setters‘ funcionan mediante asignación, no como funciones. Son un canal directo para modificar el valor de las propiedades del objeto instanciado.
// El ‘get‘, como los anteriores, no es una función que tenga que ser ejecutada, sino un acceso a la propiedad del objeto instanciado.

class Vehiculo {
      constructor(placa, marca, modelo){
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
      };

      set_placa(pl){
        this.placa = pl;
      }
      set_marca (ma){
        this.marca = ma;
      }    
      set_modelo(mo){
        this.modelo =mo;
      }
      get_placa(){
        return this.placa;
      }
      get_marca(){
        return this.marca;
      }
      get_modelo(){
        return this.modelo;
      }
 
}

let v = new Vehiculo('MOT878','Mazda', '2010');
//console.log(v);
v.set_placa('TER200')
//v.set('MOT878','Mazda', '2010');
//v.set('TER200','Monza', '2011')
//console.log(v.get_placa());
v.set_modelo('Toyota')
//console.log(v.get_modelo())
////////////////////////////////////////  Metodos Estaticos //////////////////////////////////////////////
class Tools { /// HELPERS -> Los métodos estáticos son aquellos que se ejecutan a través/desde de la propia clase, no desde sus instancias pero si aplica herendando.
    static strToURL (str){
      return encodeURIComponent(str).replace(/%20/g,'+');
    }
}

//console.log(Tools.strToURL('La donna e mobile')); //Funciona porque se llama desde la clase directa HELPER...

var toolkit = new Tools();
//toolkit.strToURL('La donna e mobile'); // No funciona porque se llama desde una instancia
//console.log(toolkit);

//////////////////////////////////// ENCAPSULACION /////////////////////////////////////////////////////////////////////////////////
//////// Para la version 2015->ES6 No existe encapsulamiento para esto se debe acudir a malabares para solucion encapsulamiento.
/////////////// se utiliza un array dinamico WeakMap como metodo de encapsulamiento...
let jugadorMap = new WeakMap();


class Jugador {

      constructor(vida = 100){
        jugadorMap.set(this, {vida:vida})
      }

      set_vidapublica(v){
        jugadorMap.get(this).vida = v;
      }

      get_vida(){
        return jugadorMap.get(this).vida;
      }
}

let jugador_uno = new Jugador();
//jugador_uno.vida = 50;
//console.log(jugador_uno);
//jugador_uno.vida = 30;
//console.log(jugador_uno);

//////////////////////////////////// MODULOS /////////////////////////////////////////////////////////////////////////////////
let c = new Cuadrado(2);
//console.log(c.ancho);
//////////////////////////////////// PROMESAS /////////////////////////////////////////////////////////////////////////////////
// Una promesa es una nueva forma de implementar esta asincronía pero sin usar callbacks, lo que hace que se lea mucho más fácil.
//El ciclo de vida de una promesa es muy sencillo: cuando se crea se queda en estado pending esperando a que se resuelva o se rechace.

// const promise = new Promise((resolve, reject) => {
// const number = Math.floor(Math.random() * 10);
// console.log(number)
// 	setTimeout( () => number > 5
// 			? resolve(number)
// 			: reject(new Error('Menor a 5')),
// 		1000
// 	);
// });

// promise
// 	.then(number => console.log(number))
// 	.catch(error => console.error(error));

//////////////////// Recibiendo Parametros ///////////////////////////////////////////////
//  function randomDelayed(max = 10, expected = 5, delay =  1000) {
//     return new Promise((resolve, reject) => {
//       const number = Math.floor( Math.random() * max)
//       console.log(delay)
//       console.log(number)
//       setTimeout(
//         () => number > expected
//           ? resolve(number)
//           : reject(new Error('número menor al esperado')),
//         delay
//       )
//     })
//   };
 
// randomDelayed(100, 75, 2500)
//       .then(number => console.log(number))
//       .catch(error => console.error(error));

function exitocb(resultado){
    console.log("Exito: "+resultado);
}

function fallocb(error){
    console.log("Error: "+error);
}

//hazAlgo(exitocb, fallocb)

//let promesa =  new hazAlgo();
//promesa.then(exitocb, fallocb)


/////////////////////////////////////////// Async y await ////////////////////////////////////////

// // declaración de función asíncrona
// async function requestGet(url) {
//   let response = await NodeFetch(url);
//   if (response.ok) {
//     return await response.json();
//   }
//   throw new Error(`Status: ${response.status}, Status text: ${response.statusText}`);
// }
 
// // llamada con función asíncrona
// (async () => {
//   try {
//     const posts = await requestGet('https://jsonplaceholder.typicode.com/posts');
//     const firstPostUser = posts[0]['userId'];
//     // console.log(firstPostUser);
//     const user = await requestGet(`https://jsonplaceholder.typicode.com/users/${firstPostUser}`);
//     console.log(`User: ${user.name}`);
//   } catch (err) {
//     console.log(err);
//   }
// })();
 
// // llamada con promesas
// requestGet('https://jsonplaceholder.typicode.com/posts')
//   .then((posts) => {
//     let firstPostUser = posts[0]['userId'];
//     // console.log(`firstPostUser: ${firstPostUser}`)
//     return requestGet(`https://jsonplaceholder.typicode.com/users/${firstPostUser}`);
//   })
//   .then((user) => {
//     console.log(`User: ${user.name}`);
//   })
//   .catch((err) => {
//     console.log(err);
//   });
// ////////////////////////////////////// Promesas ->  ES8 - Async y await ////////////////////////////////////////
function resolveAfter2Seconds() {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve('resolved');
    }, 2000);
  });
}

async function asyncCall() {
  console.log('calling');
  var result = await resolveAfter2Seconds();
  console.log(result);
  // expected output: 'resolved'
}

//asyncCall();

function resolveAfter2seconds(x){
  return new Promise (resolve => { setTimeout(() => { resolve(x) }, 2000)} );
}

async function add1(x){
  const a = await resolveAfter2seconds(20);
  const b = await resolveAfter2seconds(30);
  return x + a + b;
}

//add1(10).then( v => {console.log(v)});

async function add2(x){
  const p_a =  await resolveAfter2seconds(20);
  const p_b =  await resolveAfter2seconds(40);
  return x + p_a + p_b;
}

//add2(20).then(v => {console.log(v)})

/////////////////////////////////////////////////// Proxies e Interceptores ////////////////////////////
//// En esencia un Proxy es un objeto que recubre a otro ya existente, y que permite interceptar algunas operaciones sobre él
let cuadra = {
      l: 3,
      cua: function(){ return this.l * this.l;}
}

let square = { 
        lado: 4,
        area_square : function() {return this.lado * this.lado;}
}

let squarehandlers = {
    get: function(target, prop){ 
         console.log("Consulta el valor de la propiedad: "+prop);
         //return target[prop]
        }

}
let psquare = new Proxy(square, squarehandlers);
// console.log("Valor Lado : "+cuadra.l)
// console.log("Valor Area : "+cuadra.cua())
// console.log("Valor Proxy Lado : "+psquare.lado)
// console.log("Valor Proxy Lado : "+psquare.area_square())

/////////////////////////////////// . Strings y Literales ////////////////////////////////////////////

// let precio = 2950;
// const IVA = 1.21
// let cadena = `El precio es ${precio*IVA} euros`;
// console.log(cadena);


let precio = 2950;
const IVA = 1.21
function cadenaPrecio(cadenas, ...values){
return `El precio es ${values[0]} euros`;
}
//console.log(cadenaPrecio `${precio*IVA}`); //El precio es 3569.5 euros
precio = 10;
//console.log(cadenaPrecio `${precio*IVA}`); //El precio es 12.1 euros
 
//console.log(String.raw`Gracias por su visita.\n\tEl precio es:\n\t${precio*IVA}euros`);

//////////////////////////////// Nuevos métodos de String ////////////////////////////////////////
//startsWith: comprueba si una cadena comienza por otra
// endsWith: comprueba si una cadena finaliza por otra
// Includes: comprueba si una cadena está incluida en otra
// repeat: repite una cadena n veces

// console.log('abcdef'.startsWith('a')); //true
// console.log('abcdef'.startsWith('abc')); //true
// console.log('abcdef'.startsWith('bc')); //false
// console.log('abcdef'.includes('bc')); //true
// console.log('abcdef'.endsWith('bc')); //false
// console.log('abcdef'.endsWith('ef')); //true
// console.log('abc'.repeat(3)); //abcabcabc


///////////////////////////// Novedades en los objetos Math y Number //////////////////////////////

// let aa = 0xFF; //255 en hexadecimal
// let bb = 0o377; //255 en octal
// let cc = 0b11111111; //255 en binario
// console.log(aa === bb); //true
// console.log(aa === cc); //true
//console.log("Numeros..................")
//console.log(0.1 + 0.2 == 0.3); //false
//console.log(0.25 + 0.125 == 0.375); //true
let aaa = 0.1
let bbb = 0.2
let ccc = 0.3
//console.log((aaa+bbb).toExponential(2) === ccc.toExponential(2))

// console.log((aaa+bbb-ccc).toExponential(20));

////////////////////////////////// La clase Math /////////////////////////////////////////////////

Math.cosh(1) //coseno hiperbolico
Math.sinh(1) //seno hiperbólico
Math.tanh(1) //tangente hiperbólica
Math.acosh(1.5430806348152437) //arco coseno hiperbólico
Math.asinh(1.1752011936438014) //arco seno hiperbólico
Math.atanh(0.7615941559557649) //arco tangente hiperbólica



console.ignoredYellowBox = ['Warning: Each'];

  return (
    <div className="App">

      {<header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header> }

    </div>
  );
}

export default App;

