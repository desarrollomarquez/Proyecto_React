
class Rectangulo {
    constructor(alto, ancho){
    this.alto = alto;
    this.ancho = ancho;
    };
    area_r(){
    return this.alto * this.ancho;
    };
};

class Cuadrado extends Rectangulo {
    constructor(lado){
    super(lado,lado);
    this.lado = lado;
    };
};

class Triangulo  extends Rectangulo{
  constructor(base, altura){
    super(base, altura)
    this.base    = base;
    this.altura  = altura;
  };
  
  area_t(){
      return (this.base * this.altura)/2;
  };
};

export {Cuadrado, Triangulo};

