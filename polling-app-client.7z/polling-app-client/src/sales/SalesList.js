import React, { Component } from 'react';
import { getAllSales, getUserCreatedSales, getUserVotedSales } from '../util/APIUtils';
import LoadingIndicator  from '../common/LoadingIndicator';
import { Button, Icon } from 'antd';
import { SALE_LIST_SIZE } from '../constants';
import { withRouter } from 'react-router-dom';
import './SalesList.css';
import Sale from './Sale';

class SalesList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            sales: [],
            page: 0,
            size: 10,
            totalElements: 0,
            totalPages: 0,
            last: true,
            currentVotes: [],
            isLoading: false
        };
        this.loadSalesList = this.loadSalesList.bind(this);
        this.handleLoadMore = this.handleLoadMore.bind(this);
    }

    loadSalesList(page = 0, size = SALE_LIST_SIZE) {
        let promise;
        if(this.props.username) {
            if(this.props.type === 'USER_CREATED_SALES') {
                promise = getUserCreatedSales(this.props.username, page, size);
            } else if (this.props.type === 'USER_VOTED_SALES') {
                promise = getUserVotedSales(this.props.username, page, size);                               
            }
        } else {
            promise = getAllSales(page, size);
        }

        if(!promise) {
            return;
        }

        this.setState({
            isLoading: true
        });

        promise            
        .then(response => {
            const sales = this.state.sales.slice();
            const currentVotes = this.state.currentVotes.slice();

            this.setState({
                sales: sales.concat(response.content),
                page: response.page,
                size: response.size,
                totalElements: response.totalElements,
                totalPages: response.totalPages,
                last: response.last,
                currentVotes: currentVotes.concat(Array(response.content.length).fill(null)),
                isLoading: false
            })
        }).catch(error => {
            this.setState({
                isLoading: false
            })
        });  
        
    }

    componentDidMount() {
        this.loadSalesList();
    }

    componentDidUpdate(nextProps) {
        if(this.props.isAuthenticated !== nextProps.isAuthenticated) {
            // Reset State
            this.setState({
                sales: [],
                page: 0,
                size: 10,
                totalElements: 0,
                totalPages: 0,
                last: true,
                currentVotes: [],
                isLoading: false
            });    
            this.loadSalesList();
        }
    }

    handleLoadMore() {
        this.loadSalesList(this.state.page + 1);
    }

    render() {
        const saleViews = [];
        this.state.sales.forEach((sale, saleIndex) => {
            saleViews.push(<Sale 
                key={sale.id} 
                sale={sale}
                />)            
        });

        return (
            <div className="sales-container">
                {saleViews}
                {
                    !this.state.isLoading && this.state.sales.length === 0 ? (
                        <div className="no-sales-found">
                            <span>No Sales Found.</span>
                        </div>    
                    ): null
                }  
                {
                    !this.state.isLoading && !this.state.last ? (
                        <div className="load-more-sales"> 
                            <Button type="dashed" onClick={this.handleLoadMore} disabled={this.state.isLoading}>
                                <Icon type="plus" /> Load more
                            </Button>
                        </div>): null
                }              
                {
                    this.state.isLoading ? 
                    <LoadingIndicator />: null                     
                }
            </div>
        );
    }
}

export default withRouter(SalesList);