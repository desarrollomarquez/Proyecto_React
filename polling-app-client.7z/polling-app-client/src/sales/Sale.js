import React, { Component } from 'react';
import './Sale.css';

class Sale extends Component {

    render() {       
        return (
        
        <div>
              <table>
                <thead>
                <tr>
                    <th>Fecha Venta</th>
                    <th>Valor</th>
                    <th>Cantidad</th>
                </tr>
                </thead>
                <tbody>
                {this.props.sale.length > 0 ? (
                    this.props.sale.map(iter => (
                    <tr key={iter.id}>
                        <td>{this.props.sale.fventa}</td>
                        <td>{this.props.sale.valor}</td>
                        <td>
                        <button
                           // onClick={() => {this.props.editRow(sale)}}
                            className="button muted-button"
                        >
                            Edit
                        </button>
                        <button
                          //  onClick={() => this.props.deleteUser(sale.id)}
                            className="button muted-button"
                        >
                            Delete
                        </button>
                        </td>
                    </tr>
                    ))
                ) : (
                    <tr>
                    <td colSpan={3}>No Sales</td>
                    </tr>
                )}
                </tbody>
            </table>

        </div>
        
        
        );
    }
}



export default Sale;