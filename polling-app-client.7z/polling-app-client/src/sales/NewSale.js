import React, { Component } from 'react';
import { NAME_MIN_LENGTH, NID_MAX_LENGTH,  NAME_MAX_LENGTH } from '../constants';
import { createSale } from '../util/APIUtils';
import './NewSale.css';
import { Form, Input, Button, notification } from 'antd';
const FormItem = Form.Item;


class NewSale extends Component {
    constructor(props) {
        super(props);
        this.state = {
            fventa: {
                value: ''
            }, 
            valor: {
                value: ''
            }, 
            cantidad: {
                value: ''
            }, 
            iva: {
                value: ''
            },
            cliente: {
                value: ''
            }
           
        };
       
        this.handleInputChange = this.handleInputChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.isFormInvalid = this.isFormInvalid.bind(this);
    }


    handleInputChange(event, validationFun) {
        const target = event.target;
        const inputName = target.name;        
        const inputValue = target.value;

        this.setState({
            [inputName] : {
                value: inputValue,
                ...validationFun(inputValue)
            }
        });
    }

    handleSubmit(event) {
        event.preventDefault();
    
        const saleRequest = {
            fventa: this.state.fventa.value,
            valor: this.state.valor.value,
            cantidad: this.state.cantidad.value,
            iva: this.state.iva.value,
            cliente: this.state.cliente.value,
        };
        createSale(saleRequest)
        .then(response => {
            notification.success({
                message: 'LasVentas.co WebApp',
                description: "Thank you! You're successfully registered. Please Login to continue!",
            });          
            this.props.history.push("/sales");
        }).catch(error => {
            notification.error({
                message: 'LasVentas.co WebApp',
                description: error.message || 'Sorry! Something went wrong. Please try again!'
            });
        });
    }
   

    isFormInvalid() {
        if  (this.state.fventa.validateStatus !== 'success' &&
             this.state.valor.validateStatus !== 'success' &&
             this.state.cantidad.validateStatus !== 'success' &&
             this.state.iva.validateStatus !== 'success' &&
             this.state.cliente.validateStatus !== 'success'
        ){
            return true;
        }
    }

    render() {
        return (
            <div className="sale-container">
                <h1 className="page-title"> Sale </h1>
                <div className="sale-content">
                    <Form onSubmit={this.handleSubmit} className="sale-form">
                        <FormItem 
                            label="Fventa"
                            validateStatus={this.state.fventa.validateStatus}
                            help={this.state.fventa.errorMsg}>
                            <Input 
                                size="large"
                                name="fventa"
                                autoComplete="off"
                                placeholder="Your fventa"
                                value={this.state.fventa.value} 
                                onChange={(event) => this.handleInputChange(event, this.validatefVenta)} />    
                        </FormItem>
                        <FormItem label="Valor"
                            hasFeedback
                            validateStatus={this.state.valor.validateStatus}
                            help={this.state.valor.errorMsg}>
                            <Input 
                                size="large"
                                name="valor" 
                                autoComplete="off"
                                placeholder="Your Valor"
                                value={this.state.valor.value} 
                                onChange={(event) => this.handleInputChange(event, this.validateValor)} />    
                        </FormItem>
                        <FormItem 
                            label="Cantidad"
                            hasFeedback
                            validateStatus={this.state.cantidad.validateStatus}
                            help={this.state.cantidad.errorMsg}>
                            <Input 
                                size="large"
                                name="cantidad" 
                                autoComplete="off"
                                placeholder="Your cantidad"
                                value={this.state.cantidad.value} 
                                onChange={(event) => this.handleInputChange(event, this.validateCantidad)} />    
                        </FormItem>
                        <FormItem 
                            label="Iva"
                            validateStatus={this.state.iva.validateStatus}
                            help={this.state.iva.errorMsg}>
                            <Input 
                                size="large"
                                name="iva"
                                autoComplete="off"
                                placeholder="Your Iva"
                                value={this.state.iva.value}
                                onChange={(event) => this.handleInputChange(event, this.validateIva)} />    
                        </FormItem>
                        <FormItem 
                            label="cliente"
                            validateStatus={this.state.cliente.validateStatus}
                            help={this.state.cliente.errorMsg}>
                            <Input 
                                size="large"
                                name="cliente"
                                autoComplete="off"
                                placeholder="Your cliente"
                                value={this.state.cliente.value}
                                onChange={(event) => this.handleInputChange(event, this.validateCliente)} />    
                        </FormItem>
                        <FormItem>
                            <Button type="primary"
                                htmlType="submit" 
                                size="large" 
                                className="sale-form-button"
                                disabled={this.isFormInvalid()}
                                > Create Sale </Button>
                        </FormItem>
                    </Form>
                </div>
            </div>
        );
    }

    // Validation Functions

    validatefVenta = (fventa) => {
        if(fventa.length < NAME_MIN_LENGTH) {
            return {
                validateStatus: 'error',
                errorMsg: `Fventa is too short (Minimum ${NAME_MIN_LENGTH} characters needed.)`
            }
        } else if (fventa.length > NAME_MAX_LENGTH) {
            return {
                validationStatus: 'error',
                errorMsg: `Fventa is too long (Maximum ${NAME_MAX_LENGTH} characters allowed.)`
            }
        } else {
            return {
                validateStatus: 'success',
                errorMsg: null,
              };            
        }
    }

    validateValor = (valor) => {
        if(!valor) {
            return {
                validateStatus: 'error',
                errorMsg: 'valor may not be empty'                
            }
        }

        const NID_REGEX = RegExp('^[0-9]+$');
        if(!NID_REGEX.test(valor)) {
            return {
                validateStatus: 'error',
                errorMsg: 'Valor not valid'
            }
        }

        if(valor.length > NID_MAX_LENGTH) {
            return {
                validateStatus: 'error',
                errorMsg: `Valor is too long (Maximum ${NID_MAX_LENGTH} characters allowed)`
            }
        }

        return {
            validateStatus: null,
            errorMsg: null
        }
    }

    validateCantidad = (cantidad) => {
        if(!cantidad) {
            return {
                validateStatus: 'error',
                errorMsg: 'Cantidad may not be empty'                
            }
        }

        const NID_REGEX = RegExp('^[0-9]+$');
        if(!NID_REGEX.test(cantidad)) {
            return {
                validateStatus: 'error',
                errorMsg: 'Cantidad not valid'
            }
        }

        if(cantidad.length > NID_MAX_LENGTH) {
            return {
                validateStatus: 'error',
                errorMsg: `Cantidad is too long (Maximum ${NID_MAX_LENGTH} characters allowed)`
            }
        }

        return {
            validateStatus: null,
            errorMsg: null
        }
    }

    validateIva = (iva) => {
        if(!iva) {
            return {
                validateStatus: 'error',
                errorMsg: 'Cantidad may not be empty'                
            }
        }

        const NID_REGEX = RegExp('^[0-9]+$');
        if(!NID_REGEX.test(iva)) {
            return {
                validateStatus: 'error',
                errorMsg: 'Iva not valid'
            }
        }

        if(iva.length > NID_MAX_LENGTH) {
            return {
                validateStatus: 'error',
                errorMsg: `Iva is too long (Maximum ${NID_MAX_LENGTH} characters allowed)`
            }
        }

        return {
            validateStatus: null,
            errorMsg: null
        }
    }

    validateCliente = (cliente) => {
        if(!cliente) {
            return {
                validateStatus: 'error',
                errorMsg: 'Cliente may not be empty'                
            }
        }

        const NID_REGEX = RegExp('^[0-9]+$');
        if(!NID_REGEX.test(cliente)) {
            return {
                validateStatus: 'error',
                errorMsg: 'Cliente not valid'
            }
        }

        if(cliente.length > NID_MAX_LENGTH) {
            return {
                validateStatus: 'error',
                errorMsg: `Iva is too long (Maximum ${NID_MAX_LENGTH} characters allowed)`
            }
        }

        return {
            validateStatus: null,
            errorMsg: null
        }
    }
}

export default NewSale;