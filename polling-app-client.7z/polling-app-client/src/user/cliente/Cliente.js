import React, { Component } from 'react';
import {  NAME_MIN_LENGTH, NID_MAX_LENGTH, DIR_MAX_LENGTH, NAME_MAX_LENGTH, TEL_MAX_LENGTH } 
from '../../constants';
import { cliente, checkNidAvailability, checkTelefonoAvailability } from '../../util/APIUtils';
import './Cliente.css';
import { Form, Input, Button, notification } from 'antd';
const FormItem = Form.Item;

class Cliente extends Component {
    constructor(props) {
        super(props);
        this.state = {
            fullname: {
                value: ''
            },
            nid: {
                value: ''
            },
            direccion: {
                value: ''
            },
            telefono: {
                value: ''
            }
        }
        this.handleInputChange = this.handleInputChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.validateNidAvailability = this.validateNidAvailability.bind(this);
        this.validateTelefonoAvailability = this.validateTelefonoAvailability.bind(this);
        this.isFormInvalid = this.isFormInvalid.bind(this);
    }

    handleInputChange(event, validationFun) {
        const target = event.target;
        const inputName = target.name;        
        const inputValue = target.value;

        this.setState({
            [inputName] : {
                value: inputValue,
                ...validationFun(inputValue)
            }
        });
    }

    handleSubmit(event) {
        event.preventDefault();
    
        const clienteRequest = {
            fullname: this.state.fullname.value,
            nid: this.state.nid.value,
            direccion: this.state.direccion.value,
            telefono: this.state.telefono.value
        };
        cliente(clienteRequest)
        .then(response => {
            notification.success({
                message: 'LasVentas.co WebApp',
                description: "Thank you! You're successfully registered. Please Login to continue!",
            });          
            this.props.history.push("/cliente");
        }).catch(error => {
            notification.error({
                message: 'LasVentas.co WebApp',
                description: error.message || 'Sorry! Something went wrong. Please try again!'
            });
        });
    }

    isFormInvalid() {
        return !(this.state.fullname.validateStatus === 'success' &&
            this.state.nid.validateStatus === 'success' &&
            this.state.direccion.validateStatus === 'success' &&
            this.state.telefono.validateStatus === 'success'
        );
    }

    render() {
        return (
            <div className="cliente-container">
                <h1 className="page-title"> Cliente </h1>
                <div className="cliente-content">
                    <Form onSubmit={this.handleSubmit} className="cliente-form">
                        <FormItem 
                            label="Full Name"
                            validateStatus={this.state.fullname.validateStatus}
                            help={this.state.fullname.errorMsg}>
                            <Input 
                                size="large"
                                name="fullname"
                                autoComplete="off"
                                placeholder="Your full name"
                                value={this.state.fullname.value} 
                                onChange={(event) => this.handleInputChange(event, this.validatefullName)} />    
                        </FormItem>
                        <FormItem label="Numero Identificacion"
                            hasFeedback
                            validateStatus={this.state.nid.validateStatus}
                            help={this.state.nid.errorMsg}>
                            <Input 
                                size="large"
                                name="nid" 
                                autoComplete="off"
                                placeholder="A unique nid"
                                value={this.state.nid.value} 
                                onBlur={this.validateNidAvailability}
                                onChange={(event) => this.handleInputChange(event, this.validateNid)} />    
                        </FormItem>
                        <FormItem 
                            label="Direccion"
                            hasFeedback
                            validateStatus={this.state.direccion.validateStatus}
                            help={this.state.direccion.errorMsg}>
                            <Input 
                                size="large"
                                name="direccion" 
                                autoComplete="off"
                                placeholder="Your direccion"
                                value={this.state.direccion.value} 
                                onChange={(event) => this.handleInputChange(event, this.validateDireccion)} />    
                        </FormItem>
                        <FormItem 
                            label="Telefono"
                            validateStatus={this.state.telefono.validateStatus}
                            help={this.state.telefono.errorMsg}>
                            <Input 
                                size="large"
                                name="telefono"
                                autoComplete="off"
                                placeholder="Your Number telefono"
                                value={this.state.telefono.value}
                                onBlur={this.validateTelefonoAvailability}
                                onChange={(event) => this.handleInputChange(event, this.validateTelefono)} />    
                        </FormItem>
                        <FormItem>
                            <Button type="primary"
                                htmlType="submit" 
                                size="large" 
                                className="cliente-form-button"
                                disabled={this.isFormInvalid()}>Cliente</Button>
                        </FormItem>
                    </Form>
                </div>
            </div>
        );
    }

    // Validation Functions

    validatefullName = (fullname) => {
        if(fullname.length < NAME_MIN_LENGTH) {
            return {
                validateStatus: 'error',
                errorMsg: `FullName is too short (Minimum ${NAME_MIN_LENGTH} characters needed.)`
            }
        } else if (fullname.length > NAME_MAX_LENGTH) {
            return {
                validationStatus: 'error',
                errorMsg: `FullName is too long (Maximum ${NAME_MAX_LENGTH} characters allowed.)`
            }
        } else {
            return {
                validateStatus: 'success',
                errorMsg: null,
              };            
        }
    }

    validateNid = (nid) => {
        if(!nid) {
            return {
                validateStatus: 'error',
                errorMsg: 'NID may not be empty'                
            }
        }

        const NID_REGEX = RegExp('^[0-9]+$');
        if(!NID_REGEX.test(nid)) {
            return {
                validateStatus: 'error',
                errorMsg: 'Nid not valid'
            }
        }

        if(nid.length > NID_MAX_LENGTH) {
            return {
                validateStatus: 'error',
                errorMsg: `Nid is too long (Maximum ${NID_MAX_LENGTH} characters allowed)`
            }
        }

        return {
            validateStatus: null,
            errorMsg: null
        }
    }

    validateDireccion = (direccion) => {
   //     const DIR_REGEX = RegExp("/^[a-z0-9\s,'-]*$/i")
        
        // if(!DIR_REGEX.test(direccion)) {
        //     return {
        //         validateStatus: 'error',
        //         errorMsg: 'Direccion not valid'
        //     }
        // }
 
        if (direccion.length > DIR_MAX_LENGTH) {
            return {
                validationStatus: 'error',
                errorMsg: `Direccion is too long (Maximum ${DIR_MAX_LENGTH} characters allowed.)`
            }
        } else {
            return {
                validateStatus: 'success',
                errorMsg: null,
              };            
        }
    }

    validateTelefono = (telefono) => {
        if(!telefono) {
            return {
                validateStatus: 'error',
                errorMsg: 'Telefono may not be empty'                
            }
        }

        const TEL_REGEX = RegExp('^[0-9]+$');
        if(!TEL_REGEX.test(telefono)) {
            return {
                validateStatus: 'error',
                errorMsg: 'Telefono not valid'
            }
        }

        if(telefono.length > TEL_MAX_LENGTH) {
            return {
                validateStatus: 'error',
                errorMsg: `Telefono is too long (Maximum ${TEL_MAX_LENGTH} characters allowed)`
            }
        }

        return {
            validateStatus: null,
            errorMsg: null
        }
    }

    validateNidAvailability() {
        // First check for client side errors in username
        const nidValue = this.state.nid.value;
        const nidValidation = this.validateNid(nidValue);

        if(nidValidation.validateStatus === 'error') {
            this.setState({
                nid: {
                    value: nidValue,
                    ...nidValidation
                }
            });
            return;
        }

        this.setState({
            nid: {
                value: nidValue,
                validateStatus: 'validating',
                errorMsg: null
            }
        });

        checkNidAvailability(nidValue)
        .then(response => {
            if(response.available) {
                this.setState({
                    nid: {
                        value: nidValue,
                        validateStatus: 'success',
                        errorMsg: null
                    }
                });
            } else {
                this.setState({
                    nid: {
                        value: nidValue,
                        validateStatus: 'error',
                        errorMsg: 'This Nid is already taken'
                    }
                });
            }
        }).catch(error => {
            // Marking validateStatus as success, Form will be recchecked at server
            this.setState({
                nid: {
                    value: nidValue,
                    validateStatus: 'success',
                    errorMsg: null
                }
            });
        });
    }

    validateTelefonoAvailability() {
        // First check for client side errors in email
        const telValue = this.state.telefono.value;
        const telValidation = this.validateTelefono(telValue);

        if(telValidation.validateStatus === 'error') {
            this.setState({
                telefono: {
                    value: telValue,
                    ...telValidation
                }
            });    
            return;
        }

        this.setState({
            telefono: {
                value: telValue,
                validateStatus: 'validating',
                errorMsg: null
            }
        });

        checkTelefonoAvailability(telValue)
        .then(response => {
            if(response.available) {
                this.setState({
                    telefono: {
                        value: telValue,
                        validateStatus: 'success',
                        errorMsg: null
                    }
                });
            } else {
                this.setState({
                    telefono: {
                        value: telValue,
                        validateStatus: 'error',
                        errorMsg: 'This Telefono is already registered'
                    }
                });
            }
        }).catch(error => {
            // Marking validateStatus as success, Form will be recchecked at server
            this.setState({
                telefono: {
                    value: telValue,
                    validateStatus: 'success',
                    errorMsg: null
                }
            });
        });
    }



}

export default Cliente;