import React from 'react';
import './App.css';

class App extends React.Component {
  constructor(props){
    super(props)
    this.state = {
      data: [
              {
                  "id":1,
                  "name":" Foo ",
                  "age":" 20 "
              },
              {
                  "id":2,
                  "name":" Bar ",
                  "age":" 30 "
              },
              {
                  "id":3,
                  "name":" Baz ",
                  "age":" 40 "
              }
            ],
        estado_ini : 0
    }

    this.setState.bind(this);
    
  }

  render(){
        return (
          <div>
            <h3>Header</h3>
             <table>
               <tbody>
                  {this.state.data.map((person, i) => <Header key = {i}  data = {person} />)}
               </tbody>
            </table>
            <Footer></Footer>
          </div>
        );

  }

}




class Header extends React.Component {
    render(){
      return (
          <tr>
            <td>{this.props.data.id}</td>
            <td>{this.props.data.name}</td>
            <td>{this.props.data.age}</td>
          </tr>
      );
    }
} 


class Footer extends React.Component {
    render(){
       return (
         <h3>Footer</h3>
       );
     }
 }


export default App;
